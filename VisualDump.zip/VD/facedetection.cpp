#include "facedetection.h"

FaceDetection::FaceDetection()
{

}

FaceDetection::~FaceDetection()
{

}

