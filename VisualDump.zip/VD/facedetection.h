#ifndef FACEDETECTION_H
#define FACEDETECTION_H


#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/face/facerec.hpp>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <fstream>
#include <sstream>


using namespace cv;
using namespace std;


class FaceDetection
{
public:
    FaceDetection();
    ~FaceDetection();

private:




};

#endif // FACEDETECTION_H
